package pe.edu.upc.catchup.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import pe.edu.upc.catchup.R;
import pe.edu.upc.catchup.activities.AboutSourceActivity;
import pe.edu.upc.catchup.activities.SourceNewsActivity;
import pe.edu.upc.catchup.models.Source;

/**
 * Created by profesores on 9/15/17.
 */

public class SourcesAdapter extends RecyclerView.Adapter<SourcesAdapter.ViewHolder> {
    private List<Source> sources;

    public SourcesAdapter(List<Source> sources) {
        this.setSources(sources);
    }

    public SourcesAdapter() {
    }

    @Override
    public SourcesAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(
                LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.card_source, parent, false));
    }

    @Override
    public void onBindViewHolder(SourcesAdapter.ViewHolder holder, int position) {
        // TODO: Assign Logo to Widget
        Source source = sources.get(position);
        holder.newsTextView.setText(source.getName());
        holder.aboutTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Start About Source Activity
                Context context = view.getContext();
                Intent intent = new Intent(context, AboutSourceActivity.class);
                context.startActivity(intent);
            }
        });
        holder.newsTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: Start Source News Activity
                Context context = view.getContext();
                Intent intent = new Intent(context, SourceNewsActivity.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return sources.size();
    }

    public List<Source> getSources() {
        return sources;
    }

    public SourcesAdapter setSources(List<Source> sources) {
        this.sources = sources;
        return this;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView logoImageView;
        TextView nameTextView;
        TextView aboutTextView;
        TextView newsTextView;
        public ViewHolder(View itemView) {
            super(itemView);
            logoImageView = (ImageView) itemView.findViewById(R.id.logoImageView);
            nameTextView = (TextView) itemView.findViewById(R.id.nameTextView);
            aboutTextView = (TextView) itemView.findViewById(R.id.aboutTextView);
            newsTextView = (TextView) itemView.findViewById(R.id.newsTextView);

        }
    }
}
