package pe.edu.upc.catchup.network;

/**
 * Created by alumnos on 9/18/17.
 */

public class NewsApiService {
    public static String SOURCES_URL = "https://newsapi.org/v1/sources";
    public static String ARTICLES_URL = "https://newsapi.org/v1/articles";


}
