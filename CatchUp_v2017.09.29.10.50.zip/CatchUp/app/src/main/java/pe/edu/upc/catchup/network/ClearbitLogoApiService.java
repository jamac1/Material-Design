package pe.edu.upc.catchup.network;

/**
 * Created by profesores on 9/15/17.
 */

public class ClearbitLogoApiService {
    public static String LOGO_BASE_URL = "https://logo.clearbit.com/";

    public static String getUrlToLogo(String domain) {
        return LOGO_BASE_URL + domain;
    }

}
